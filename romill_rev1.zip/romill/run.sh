#!/bin/bash

cd /home/pi/.romill
sudo python3 main.py
