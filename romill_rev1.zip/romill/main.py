import time
from romill import mount_rml, list_rml, last_entry, to_serial, ping, get_ts


def rml_1_func():
    # Get filename of most recent log in device´s folder and list of all files that passed filter
    last_file_ok_1, list_ok_files_1 = list_rml(folder_1)
    
    status_1[2] = last_file_ok_1
    
    '''
    Open most recent log,
    get 19th line that contains header names,
    get data as object with all headers assiged.
    '''
    last_line_1 = last_entry(folder_1, last_file_ok_1, 19, error_log_filename_1, 1)
    
    # Return data
    return last_line_1


def rml_2_func():
    
    # Get filename of most recent log in device´s folder and list of all files that passed filter
    last_file_ok_2, list_ok_files_2 = list_rml(folder_2)
    
    status_2[2] = last_file_ok_2
    
    '''
    Open most recent log,
    get 19th line that contains header names,
    get data as object with all headers assiged.
    '''
    last_line_2 = last_entry(folder_2, last_file_ok_2, 19, error_log_filename_2, 1)  
    
    # Return data
    return last_line_2

# global variables
rml_ip_1 = "192.168.64.149"
rml_ip_2 = "192.168.64.159"

folder_1 = "romill_1/"
folder_2 = "romill_2/"

output_folder_1 = ""
output_folder_2 = ""

output_file_1 = "rml1.csv"
output_file_2 = "rml2.csv"

error_log_filename_1 = "Error.log"
error_log_filename_2 = "error.log"

interval = 0 # Interval to delay main program loop (s)

# Empty list for logging statuses
status_1 = ["","","","","","",]
status_2 = ["","","","","","",]

# Get timestamp of program init
status_1[0] = get_ts()
status_2[0] = get_ts()

#  mount storage MW_1
mount_result_1 = mount_rml(1)

#  mount storage MW_1
mount_result_2 = mount_rml(2)


# Start main program loop
while True:
      
    # Make empty dictionary to recieve data
    final_line = dict()
    
    try:
        # Try pinging the devices first
        rml_1_ping = ping(1)
        status_1[1] = rml_1_ping
        
        rml_2_ping = ping(2)
        status_2[1] = rml_2_ping
        
        # If device 1 is reachable, get data from it. Else return empty list.
        if rml_1_ping is True:
            #Get most recent entry from log file, append it to final_line
            final_line["rml1"] = rml_1_func()
            
        elif rml_1_ping is False:
            # Empty output
            final_line["rml1"] = ""
        
        # If device 1 is reachable, get data from it. Else return empty list.
        if rml_2_ping is True:
            #Get most recent entry from log file, append it to final_line
            final_line["rml2"] =  rml_2_func()
            
        elif rml_2_ping is False:
            # Empty output
            final_line["rml2"] = ""
                
        # Run serial function, pass final string to it
        to_serial(final_line)
        #print(final_line)
        
        # Wait for certain amount of time, to not get in sync with devices update rate
        time.sleep(interval)
        
        status_1[3] = "program run"
        status_1[4] = get_ts()
        
        status_2[3] = "program run"
        status_2[4] = get_ts()
        
    except:
        
        print("error")
        status_1[3] = "program failure"
        status_1[4] = get_ts()
        
        status_2[3] = "program failure"
        status_2[4] = get_ts()

    finally:
        #print("")
        print(status_1)
        print(status_2)

